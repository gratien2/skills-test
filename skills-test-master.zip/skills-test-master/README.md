# skills-test
Recruitment tests

Instructions:
+ Fork the repository
+ Clone your fork on your local environment
+ Edit the adequate files
+ Commit/push on your origin
+ Create a Pull request to the upstream repository
