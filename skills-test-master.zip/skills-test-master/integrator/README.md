# Integrator test

Implement Moodboard page UI from the sketch examples located in `integrator/sketch` folder, using JavaScript (`script.js`), CSS3 (`styles.css`) and HTML5 (`index.html`).

Libraries you can use:
+ jQuery v3.4
+ Bootstrap v4.3

Note: header and footer are pictures, focus only on the main content.
